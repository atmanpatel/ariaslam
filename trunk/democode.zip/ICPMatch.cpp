#include "tmat.h"
#include "tvec.h"
#include "ICPMatch.h"
#include "utilities.h"
#include "rstate.h"
#define MAX_LASER_RANGE 8
#define MAX_SCAN_SIZE 361
#define null NULL

// Implementation of the iterative closest point matching algorithm
bool ICPMatch(RobotPos &RobotPos, Polar *scan1, Polar *scan2, int *match_scan1_to_scan2)
{
	Cartesian cscan1[MAX_SCAN_SIZE] = {0}, cscan2[MAX_SCAN_SIZE] = {0};
	double x_init = 0.0, y_init = 0.0;
	int len_scan1 = MAX_SCAN_SIZE; 
	int len_scan2 = MAX_SCAN_SIZE;
	double phi = 0.0;

	x_init = RobotPos.x;
	y_init = RobotPos.y;
	phi = RobotPos.phi;
	
	for (int i=0; i<len_scan1; i++)
	{
		cscan1[i] = pol2cart(scan1[i].r, scan1[i].th);
		cscan2[i] = pol2cart(scan2[i].r, scan2[i].th);
	}
	
	for (int i=0; i<len_scan1; i++)
	{
		if (scan1[i].r >= MAX_LASER_RANGE)
		{
			continue;
		}
		else
		{
			double min_dist = MAX_LASER_RANGE;
			double dist = 0.0;
			int min_index = 0;			
			for (int j=0; j<len_scan2; j++)
			{
				if (scan2[i].r >= MAX_LASER_RANGE)
				{
					continue;
				}

				if (scan1[i].r > 0 && scan2[j].r > 0) // there is somthing there
				{
					dist = ComputeDist(cscan1[i].x, cscan1[i].y, 
						x_init + cscan2[j].x*cos(phi) - cscan2[j].y*sin(phi),
						y_init + cscan2[j].x*sin(phi) + cscan2[j].y*cos(phi));
					if (dist < min_dist)
					{
						min_dist = dist;
						match_scan1_to_scan2[i] = j;
					}
				}
			}
		}
	}
	return true;
}			

		
	

