#include "tmat.h"
#include "tvec.h"
#include "rstate.h"

#define SIGMA_PHI 0.03

void EKF_Compass_update(Rstate &state, double phi)
{
	double S = state.state_P(3,3) + SIGMA_PHI*SIGMA_PHI;
	double r = 0.0;	
	tmat<double> K = submatrix(state.state_P, 1, state.dims, 3, 3);
	r = phi - state.state_X(3,1);		

	state.state_X = state.state_X + r*K; // residual * K		
	state.state_P = state.state_P - S*K*transpose(K);
	return;
}