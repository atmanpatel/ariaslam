#ifndef ICP_MATCH_H
#define ICP_MATCH_H

typedef struct RobotPos 
{
	double x;
	double y;
	double phi;
} RobotPos;


#endif