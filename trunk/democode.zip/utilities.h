#ifndef UTILITIES_H
#define UTILITIES_H
#include <math.h>

typedef struct Cartesian 
{
	double x;
	double y;
} Cartesian;

typedef struct Polar
{
	double r;
	double th;
} Polar;


extern Cartesian pol2cart(double r, double th);
extern double ComputeDist(double x1, double x2, double y1, double y2);
#endif