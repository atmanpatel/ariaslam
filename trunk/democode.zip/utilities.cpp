#include "utilities.h"

Cartesian pol2cart(double r, double th)
{
	Cartesian cart;
	cart.x = r*cos(th);
	cart.y = r*sin(th);
	return cart;
}

double ComputeDist (double x1, double x2, double y1, double y2)
{
	return sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
}