#pragma warning (disable: 4786)
#ifndef RSTATE_H
#define RSTATE_H


#include "tmat.h"	// needed for determinant calculation

#include <vector>
#include <iostream>
#include <fstream>


// macro definitions 
#define PI 3.14159265
#define PMAX 10000
using namespace std;

class Rstate
{

public:
	long dims;				// number of dimensions in state vector
	long numfeatures;
	tmat<double> state_X;	// state vector
	tmat<double> state_P;	// state covariance matrix

	// constructor
	Rstate(tmat<double> &X_in , tmat<double> &P_in )
	{
		state_X = X_in;
		state_P = P_in;
		dims = X_in.nrows();
		numfeatures = 0;
	}
	//augment the state vector with a new row and properly scale the P matrix
	void add_feature(double x,double y){
		long n=1;
		//calculate the size of the new state vector
		long cur_cols_x = state_X.ncols();//current length of the state vector
		long new_rows_x = dims+2*n;
		//Note: new_cols_x = cur_cols_x;
		//calculate the size of the new P matrix
		long cur_cols_P = state_P.ncols();
		long new_cols_P = cur_cols_P+2*n;
		//Note: new_rows_P = new_rows_x
		
		tmat<double> tempx(new_rows_x,cur_cols_x,0.0);
		for(long i=1;i<=dims;i++){
			for(long j=1;j<=cur_cols_x;j++){
				tempx(i,j) = state_X(i,j);
				}
			}
		tempx(dims+1,1) = x;
		tempx(dims+2,1) = y;
		//submatrix(tempx,1,dims,1,cur_cols_x) = state_X;
		state_X = tempx;
	
		tmat<double> tempP(new_rows_x,new_cols_P,PMAX,0);
		for(long i=1;i<=dims;i++){
			for(long j=1;j<=cur_cols_P;j++){
				tempP(i,j) = state_P(i,j);
			}
		}
		//submatrix(tempP,1,dims,1,dims) = state_P;
		state_P = tempP;

		dims = new_rows_x;
		numfeatures += n;
	}

	tmat<double> get_zhat(long index){
		double phi = state_X(3,1);
		tmat<double> phat = submatrix(state_X,1,2,1,1);
		tmat<double> plihat= submatrix(state_X,2*index+2,2*index+3,1,1);
		
		double C[] = {cos(phi),-sin(phi),sin(phi),cos(phi)};
		tmat<double> Cphi(2,2,C);//the rotation matrix

		tmat<double> zhat = transpose(Cphi)*(plihat-phat);
		return zhat;
		}

	tmat<double> get_fi(long index){
		
		tmat<double> temp(2,1,0.0);
		
		temp=submatrix(state_X,2*index+2,2*index+3,1,1);
		return temp;
		}
		
	tmat<double> get_res_covariance(long index){
		double phi = state_X(3,1);
		tmat<double> phat = submatrix(state_X,1,2,1,1);
		tmat<double> plihat= submatrix(state_X,2*index+2,2*index+3,1,1);
	
		double C[] = {cos(phi),-sin(phi),sin(phi),cos(phi)};
		tmat<double> Cphi(2,2,C);//the rotation matrix

		tmat<double> R(2,2,pow(0.01,2.0),0);//measurement variance

		//build utility matrices
		double Jd[] = {0,-1,1,0};
		tmat<double> J(2,2,Jd);

		tmat<double> I22(2,2,1.0,0);//2x2 identity matrix
		tmat<double> mI22(2,2,-1.0,0); //2x2 identity matrix(-ve)
		tmat<double> o22(2,2,0.0); //2x2 zero padding
	
	plihat = submatrix(state_X,2*index+2,2*index+3,1,1);
	//compute the measurement jacobian
	tmat<double> H_R = mI22*transpose(Cphi)*hconcat(I22,J*(plihat-phat));
	//cout<<"H_R="<<H_R;
	
	tmat<double> H_Li = transpose(Cphi);
	//cout<<"H_Li="<<H_Li;

	//Compute residual covariance

	tmat<double> P_RR = submatrix(state_P,1,3,1,3);//first 3x3 submatrix
	//cout<<"P_RR="<<P_RR;
	
	tmat<double> P_LiLi_k = submatrix(state_P,2*index+2,2*index+3,2*index+2,2*index+3);//bottom right 2x2 submatrix
	//cout<<"P_LiLi_k="<<P_LiLi_k;
	
	tmat<double> S1 = H_R*P_RR*transpose(H_R); //we need this again for P_LiLi_kplus
	tmat<double> Si = S1+H_Li*P_LiLi_k*transpose(H_Li)+R;
	//cout<<"Si="<<Si;
	return Si;
	}

	void dump()
	{
		ofstream stream("rstate_output.txt");
		//fprintf(stream,"Xk(end+1,:) = [")
		stream << "Xk = [ ";
		for(long i=1;i<=dims;i++)
		{
			//fprintf(stream,"%g",state_X(i,1));
			stream << state_X(i,1) << "  ";
		}
		//fprintf(stream,"];\n");
		stream << "];" << endl;
		stream.close();
	}

	
	// destructor
	~Rstate()
	{
	}


};

#endif
