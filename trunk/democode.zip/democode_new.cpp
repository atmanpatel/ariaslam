//---libraries, defines ---------------------------------------------------------------------------
#include "Aria.h"
#include "ArLineFinder.h"
#include "tvec.h"
#include "tmat.h"
#include "rstate.h"
//#include "align.h"
#include <math.h>
#include <iostream>
#include <fstream>

using namespace std;

#define PI 3.14159265
#define FRONT_WALL_THRESHOLD 3000
#define MAX_DIST_TO_POINT 5000
//#define SIGMA_Z 10.0
//-------------------------------------------------------------------------------------------------

//---global variables -----------------------------------------------------------------------------
ArRobot robot;
float vmax = 300;
tmat<double> A(3,3,0.0);
tmat<double> x(3,1,0.0);
Rstate robotState = Rstate(x,A);

ArSick sick;
std::vector< ArSensorReading > *readings = NULL;

ArPose linesTakenPose;
int num_of_lines = 0;
float X1[10],X2[10],Y1[10],Y2[10];
ArLineSegment lineset[100];
int lineset_index = 0;
double Xi[10]={0,0,0,0,0,0,0,0,0,0},Yi[10]={0,0,0,0,0,0,0,0,0,0};
int NumFeatures;
bool isNewFeature[10]={0,0,0,0,0,0,0,0,0,0};
int featureCorresp[10]={0,0,0,0,0,0,0,0,0,0};
int nXn = 0;

bool MakingTurn = false;

ofstream outFileLines;
ofstream outFilePoints;
ofstream outFileVel;
ofstream outFile;
//-------------------------------------------------------------------------------------------------


//---function definitions -------------------------------------------------------------------------
void alignToWall(void);
bool checkIfCanAlignRight(void);
bool checkIfCanAlignLeft(void);

void lineFitting(void);
void getLines(void);
int findPoints(void);
int MahalanobisTest(double, double);

void MakeTurn();
bool TimeToMakeTurn();

Rstate EKF_propagate(Rstate &state , double Vm, double Wm, double dt, double sigma_v, double sigma_w);
Rstate EKF_update(Rstate &state , tmat<double> z,bool flag,long index);

//-------------------------------------------------------------------------------------------------

//---main function --------------------------------------------------------------------------------
int main(int argc, char **argv)
{
    //---variable declarations --------------------------------------------------------------------
    ArSonarDevice sonar;
    //---variable declarations complete------------------------------------------------------------
    
    //---initializations --------------------------------------------------------------------------
    Aria::init();
    ArSimpleConnector connector(&argc, argv);
    connector.parseArgs();
    if(argc>1)
    {
        connector.logOptions();
        exit(1);
    }
    robot.addRangeDevice(&sick);
    robot.addRangeDevice(&sonar);
    if(!connector.connectRobot(&robot))
    {
        printf("Could not connect to robot... exiting\n");
        Aria::shutdown();
        return 1;
    }
    robot.comInt(ArCommands::SOUNDTOG, 0);
    robot.runAsync(true);
    connector.setupLaser(&sick);
    sick.runAsync();
    if (!sick.blockingConnect())
    {
        printf("Could not connect to sick laser... exiting\n");
        Aria::shutdown();
        return 1;
    }
    robot.lock();
    robot.comInt(ArCommands::ENABLE, 1);
    robot.unlock();
    ArUtil::sleep(100);
    //---initializations complete------------------------------------------------------------------
    
    //---enter your code here----------------------------------------------------------------------
    
    outFilePoints.open("laser_points.txt");
    outFileLines.open("laser_lines.txt");
    outFileVel.open("velocities.txt");
    outFile.open("details.txt");
	ofstream stream("rstate_output.txt");
	stream << "Xk = [];" << endl;
	stream.close();
    
    outFileLines << endl << endl << endl << "lineset=[];" << endl;
    robot.lock();
    robot.setVel(vmax);
    robot.unlock();
    ArUtil::sleep(1000);
    ArTime myTime, myTimeVel;
    myTime.setToNow();
    myTimeVel.setToNow();
    outFileVel << myTimeVel.mSecSince() << " " << robot.getVel() << " " << robot.getRotVel() << endl;
    while(1)//myTimeVel.mSecSince()<60000)
    {
        for(int i=0;i<5;i++)
        {
            while(myTime.mSecSince() < (50*(i+1)) );
            float vm = robot.getVel();
            float wm = robot.getRotVel();
            outFileVel << myTimeVel.mSecSince() << " " << vm << " " << wm << endl;
            robotState = EKF_propagate(robotState, vm, wm, 0.05, 0.01*vm, .04*vm);
            robotState.dump();
        }
        alignToWall();
        for(int i=5;i<10;i++)
        {
            while(myTime.mSecSince() < (50*(i+1)) );
            float vm = robot.getVel();
            float wm = robot.getRotVel();
            outFileVel << myTimeVel.mSecSince() << " " << vm << " " << wm << endl;
            robotState = EKF_propagate(robotState, vm, wm, 0.05, 0.01*vm, .04*vm);
            robotState.dump();
        }
        // do lineFitting() and findPoints() every 500ms
        myTime.setToNow();
        lineFitting();
        if (TimeToMakeTurn())
        {
            printf("% Time to make a turn!!\n");
            MakingTurn = true;
            MakeTurn();
            while(myTime.mSecSince() < 500);
            MakingTurn = false;
        }
        
    }
    outFile << "]; %ALL TASKS COMPLETED!!!" << endl;
    outFileLines.close();
    outFilePoints.close();
    outFileVel.close();
    outFile.close();
    //---end of code-------------------------------------------------------------------------------
    
    //---shutdown procedure------------------------------------------------------------------------
    //sick.disconnect();
    //robot.disconnect();
    robot.lock();
    robot.setVel(0);
    robot.unlock();
    ArUtil::sleep(1000);
    Aria::shutdown();
    return 1;
}
//---end of main-----------------------------------------------------------------------------------

//---alignToWall function--------------------------------------------------------------------------
void alignToWall(void)
{
    
    outFilePoints << endl << robot.getX() << " " << robot.getY() << " " << robot.getTh() ;
    sick.lockDevice();
    readings = sick.getRawReadingsAsVector();
    sick.unlockDevice();
    for (int i = 0; i < 180 ; i++)
        outFilePoints << (*readings)[i].getRange() << " " << (*readings)[i].getLocalX() << " " << (*readings)[i].getLocalY();
    
    if (checkIfCanAlignRight() && checkIfCanAlignLeft())
    {
        float mR = ((*readings)[155].getLocalY() - (*readings)[170].getLocalY())/((*readings)[155].getLocalX() - (*readings)[170].getLocalX());
        float thetaR = atan(mR)*180/PI;
        //cout << "% Angle to Right Wall = " << thetaR << " degrees" << endl;
        outFile << "% Angle to Right Wall = " << thetaR << " degrees" << endl;
        float mL = ((*readings)[25].getLocalY() - (*readings)[10].getLocalY())/((*readings)[25].getLocalX() - (*readings)[10].getLocalX());
        float thetaL = atan(mL)*180/PI;
        //cout << "% Angle to Left Wall = " << thetaL << " degrees" << endl;
        outFile << "% Angle to Left Wall = " << thetaL << " degrees" << endl;
        float distToRightWall = 0.0, distToLeftWall = 0.0;
        for(int i=0;i<=15;i++)
        {
            distToRightWall += ((*readings)[155+i].getRange())*cos((25-thetaR-i)*PI/180)/15.0;
            distToLeftWall += ((*readings)[25-i].getRange())*cos((25-thetaL-i)*PI/180)/15.0;
        }
        
        //cout << "% Distance to Right Wall = " << distToRightWall << " mm" << endl;
        //cout << "% Distance to Left Wall = " << distToLeftWall << " mm" << endl;
        
        outFile << "% Distance to Right Wall = " << distToRightWall << " mm" << endl;
        outFile << "% Distance to Left Wall = " << distToLeftWall << " mm" << endl;
        
        float theta = (thetaL+thetaR)/2;
        float LeftThresh = 950, RightThresh = 950, thetaThresh = 2, corrTheta = 0;
        
        //cout << "fabs(theta) > thetaThresh) : " << (fabs(theta) > thetaThresh) << endl;
        //cout << "distToRightWall < RightThresh) : " << (distToRightWall < RightThresh) << endl;
        //cout << "distToLeftWall < LeftThresh) : " << (distToLeftWall < LeftThresh) << endl;
        corrTheta = ((theta/3) * double(fabs(theta) > thetaThresh)) + (5 * double(distToRightWall < RightThresh)) - (5 * double(distToLeftWall < LeftThresh));
        robot.setDeltaHeading(corrTheta);
        
        //cout << "% Aligning to Both Walls = " << corrTheta << " degrees" << endl << endl;
        outFile << "% Aligning to Both Walls = " << corrTheta << " degrees" << endl << endl;
    }
    else if (checkIfCanAlignRight())
    {
        float mR = ((*readings)[155].getLocalY() - (*readings)[170].getLocalY())/((*readings)[155].getLocalX() - (*readings)[170].getLocalX());
        float thetaR = atan(mR)*180/PI;
        //cout << "% Angle to Right Wall = " << thetaR << " degrees" << endl;
        outFile << "% Angle to Right Wall = " << thetaR << " degrees" << endl;
        float distToRightWall = 0.0;
        for(int i=0;i<=15;i++)
        {
            distToRightWall += ((*readings)[155+i].getRange())*cos((25-thetaR-i)*PI/180)/15.0;
        }
        //cout << "% Distance to Right Wall = " << distToRightWall << " mm" << endl;
        outFile << "% Distance to Right Wall = " << distToRightWall << " mm" << endl;
        
        float LeftThresh = 950, RightThresh = 950, thetaThresh = 2, corrTheta = 0;
        //cout << "fabs(thetaR) > thetaThresh) : " << (fabs(thetaR) > thetaThresh) << endl;
        //cout << "distToRightWall < RightThresh) : " << (distToRightWall < RightThresh) << endl;
        corrTheta = ((thetaR/3) * double(fabs(thetaR) > thetaThresh)) + (5 * double(distToRightWall < RightThresh));
        robot.setDeltaHeading(corrTheta);
        
        ////cout << "% Aligning to Right Wall = " << corrTheta << " degrees" << endl << endl;
        outFile << "% Aligning to Right Wall = " << corrTheta << " degrees" << endl << endl;
    }
    else if (checkIfCanAlignLeft())
    {
        float mL = ((*readings)[25].getLocalY() - (*readings)[10].getLocalY())/((*readings)[25].getLocalX() - (*readings)[10].getLocalX());
        float thetaL = atan(mL)*180/PI;
        ////cout << "% Angle to Left Wall = " << thetaL << " degrees" << endl;
        outFile << "% Angle to Left Wall = " << thetaL << " degrees" << endl;
        float distToLeftWall = 0.0;
        for(int i=0;i<=15;i++)
        {
            distToLeftWall += ((*readings)[25-i].getRange())*cos((25-thetaL-i)*PI/180)/15.0;
        }
        ////cout << "% Distance to Left Wall = " << distToLeftWall << " mm" << endl;
        outFile << "% Distance to Left Wall = " << distToLeftWall << " mm" << endl;
        
        float LeftThresh = 950, RightThresh = 950, thetaThresh = 2, corrTheta = 0;
        //cout << "fabs(thetaL) > thetaThresh) : " << (fabs(thetaL) > thetaThresh) << endl;
        //cout << "distToLeftWall < LeftThresh) : " << (distToLeftWall < LeftThresh) << endl;
        corrTheta = ((thetaL/3) * double(fabs(thetaL) > thetaThresh)) - (5 * double(distToLeftWall < LeftThresh));
        robot.setDeltaHeading(corrTheta);
        
        ////cout << "% Aligning to Left Wall = " << corrTheta << " degrees" << endl << endl;
        outFile << "% Aligning to Left Wall = " << corrTheta << " degrees" << endl << endl;
        
    }
    else
    {
    }
}
//---end of alignToWall function-------------------------------------------------------------------

//---checkIfCanAlign function----------------------------------------------------------------------
bool checkIfCanAlignRight(void)
{
    float m1 = ((*readings)[160].getLocalY() - (*readings)[170].getLocalY())/((*readings)[160].getLocalX() - (*readings)[170].getLocalX());
    float m2 = ((*readings)[150].getLocalY() - (*readings)[170].getLocalY())/((*readings)[150].getLocalX() - (*readings)[170].getLocalX());
    float m3 = ((*readings)[150].getLocalY() - (*readings)[160].getLocalY())/((*readings)[150].getLocalX() - (*readings)[160].getLocalX());
    float Ex2 = (m1*m1+m2*m2+m3*m3)/3;
    float Ex = (m1+m2+m3)/3;
    float SD = sqrt(Ex2 - Ex*Ex);
    // if the standard deviation of the slopes is very small then they belong to the same line and hence can be assumed to be the wall
    // we therefore use it for aligning ourselves
    if (SD<0.015)
        return true;
    else
        return false;
}
bool checkIfCanAlignLeft(void)
{
    float m1 = ((*readings)[20].getLocalY() - (*readings)[10].getLocalY())/((*readings)[20].getLocalX() - (*readings)[10].getLocalX());
    float m2 = ((*readings)[30].getLocalY() - (*readings)[10].getLocalY())/((*readings)[30].getLocalX() - (*readings)[10].getLocalX());
    float m3 = ((*readings)[30].getLocalY() - (*readings)[20].getLocalY())/((*readings)[30].getLocalX() - (*readings)[20].getLocalX());
    float Ex2 = (m1*m1+m2*m2+m3*m3)/3;
    float Ex = (m1+m2+m3)/3;
    float SD = sqrt(Ex2 - Ex*Ex);
    // if the standard deviation of the slopes is very small then they belong to the same line and hence can be assumed to be the wall
    // we therefore use it for aligning ourselves
    if (SD<0.015)
        return true;
    else
        return false;
}
//---end of checkIfCanAlign function---------------------------------------------------------------





//---lineFitting function--------------------------------------------------------------------------
void lineFitting(void)
{
    getLines();
    outFileLines << "lineset(length(lineset)).lines=[";
    lineset_index = 0;
    for (int i=0;i<num_of_lines;i++)
    {
        if (X1[i]!=0 && X2[i]!=0 && Y1[i]!=0 && Y2[i]!=0)
        {
            lineset[lineset_index] = ArLineSegment(X1[i],Y1[i],X2[i],Y2[i]);
            outFileLines << lineset[lineset_index].getX1() << " " << lineset[lineset_index].getY1() << " " << lineset[lineset_index].getX2() << " " << lineset[lineset_index].getY2() << endl;
            lineset_index++;
        }
    }
    outFileLines << "];" << endl;
    NumFeatures = findPoints();
    cout << "Number of features detected now : " << NumFeatures << endl;
    if (NumFeatures > 0)
    {
        for (int i = 0; i < NumFeatures; i++)
        {
            featureCorresp[i] = MahalanobisTest(Xi[i],Yi[i]);
            if (featureCorresp[i] == 0)
            {

                isNewFeature[i] = true;                
				cout << "New feature detected" << endl;
            }
            else
			{
                isNewFeature[i] = false;
				cout << "Correspondence : Observed feature " << i+1 << " is Known feature " << featureCorresp[i] <<  endl;
			}
            double xtemp[] = {Xi[i],Yi[i]};
            tmat<double> z(2,1,xtemp);
			cout << endl;
            robotState = EKF_update(robotState,z,isNewFeature[i],featureCorresp[i]);
        }
		cout << "-------------------" <<endl;
    }
}
//---end of lineFitting function-------------------------------------------------------------------


//---getLines function-----------------------------------------------------------------------------
void getLines(void)
{
    ArLineFinder lineFinder(&sick);
    std::map< int, ArLineFinderSegment * > *lines = NULL;
    std::map< int, ArLineFinderSegment * >::iterator iter;
    lines = lineFinder.getLines();
    linesTakenPose = lineFinder.getLinesTakenPose();
    outFileLines << "lineset(length(lineset)+1).points=[" << linesTakenPose.getX() << "," << linesTakenPose.getY() << "," << linesTakenPose.getTh() << "];" << endl;
    num_of_lines = 0;
    for (iter=lines->begin(); iter!=lines->end(); iter++)
    {
        X1[num_of_lines] = iter->second->getX1();
        Y1[num_of_lines] = iter->second->getY1();
        X2[num_of_lines] = iter->second->getX2();
        Y2[num_of_lines++] = iter->second->getY2();
    }
    
    ArPose pose1s,pose1e,pose2s,pose2e;
    float dotProd[100];
    for(int i=0;i<num_of_lines-1;i++)
    {
        pose1s = ArPose(X1[i],Y1[i],0);
        pose2s = ArPose(X1[i+1],Y1[i+1],0);
        pose1e = ArPose(X2[i],Y2[i],0);
        pose2e = ArPose(X2[i+1],Y2[i+1],0);
        dotProd[i] = ((X2[i]-X1[i])*(X2[i+1]-X1[i+1]) + (Y2[i]-Y1[i])*(Y2[i+1]-Y1[i+1]));
        dotProd[i] = dotProd[i]/(pose1s.findDistanceTo(pose1e)*pose2s.findDistanceTo(pose2e));
        if((pose1e.findDistanceTo(pose2s)<100) && (dotProd[i]>0.9))
        {
            X2[i] = X2[i+1];
            Y2[i] = Y2[i+1];
            X1[i+1] = 0;
            Y1[i+1] = 0;
            X2[i+1] = 0;
            Y2[i+1] = 0;
        }
    }
}
//---end of getLines function----------------------------------------------------------------------

//---findPoints function---------------------------------------------------------------------------
int findPoints(void)
{
    ArPose pose1s,pose1e,pose2s,pose2e;
    double m1,m2,c1,c2,dotProd,alpha1,alpha2,rob2pt,X_robot,Y_robot;
    
    double X_new=0.0, Y_new=0.0;
    nXn=0;
    if(lineset_index>1)
    {
        // if there are more than 1 lines , we find the points of intersection/interest
        for(int i=0;i<lineset_index-1;i++)
        {
            pose1s = lineset[i].getEndPoint1();
            pose1e = lineset[i].getEndPoint2();
            pose2s = lineset[i+1].getEndPoint1();
            pose2e = lineset[i+1].getEndPoint2();
            dotProd = ((pose2e.getX()-pose2s.getX())*(pose1e.getX()-pose1s.getX()) + (pose2e.getY()-pose2s.getY())*(pose1e.getY()-pose1s.getY()));
            dotProd = dotProd/(pose1s.findDistanceTo(pose1e) * pose2s.findDistanceTo(pose2e));
            if ((fabs(dotProd) < 0.5)  &&  (pose1s.findDistanceTo(pose1e)>500)   &&  (pose2s.findDistanceTo(pose2e)>500)) 
            {
                // we can find the intersection point
                m1 = (pose1e.getY()-pose1s.getY())/(pose1e.getX()-pose1s.getX());
                m2 = (pose2e.getY()-pose2s.getY())/(pose2e.getX()-pose2s.getX());
                //c1 = (pose1e.getX()*pose1s.getY()-pose1s.getX()*pose1e.getY())/(pose1e.getX()-pose1s.getX());
                //c2 = (pose2e.getX()*pose2s.getY()-pose2s.getX()*pose2e.getY())/(pose2e.getX()-pose2s.getX());
                c1 = (pose1s.getY() - m1*pose1s.getX() + pose1e.getY() - m1*pose1e.getX())/2;
                c2 = (pose2s.getY() - m2*pose2s.getX() + pose2e.getY() - m2*pose2e.getX())/2;
                X_new = -(c2-c1)/(m2-m1);
                Y_new = (m1*X_new + c1 + m2*X_new + c2)/2;
                alpha1 = (X_new - pose1e.getX())/(pose1s.getX() - pose1e.getX());
                alpha2 = (X_new - pose2e.getX())/(pose2s.getX() - pose2e.getX());
                X_robot = linesTakenPose.getX(); Y_robot = linesTakenPose.getY();
                rob2pt = sqrt((X_new - X_robot)*(X_new - X_robot) + (Y_new - Y_robot)*(Y_new - Y_robot));
                if ((alpha1 >= -0.25) && (alpha1 <= 1.25) && (alpha2 >= -0.25) && (alpha2 <= 1.25) && (rob2pt<MAX_DIST_TO_POINT))
                {
					double position[] = {X_new,Y_new};
					tmat<double> G_P_L(2,1,position);
					double rotMat[] = {cos(linesTakenPose.getTh()*PI/180), -sin(linesTakenPose.getTh()*PI/180), sin(linesTakenPose.getTh()*PI/180), cos(linesTakenPose.getTh()*PI/180)};
					tmat<double> R(2,2,rotMat);
					double positionR[] = {linesTakenPose.getX(),linesTakenPose.getY()};
					tmat<double> G_P_R(2,1,positionR);
					tmat<double> R_P_L = transpose(R)*(G_P_L - G_P_R);
                    Xi[nXn] = R_P_L(1,1);
                    Yi[nXn] = R_P_L(2,1);
                    nXn++;
					outFileLines << "Point{length(lineset)}(" << nXn << ",:)=[" << Xi[nXn-1] << "," << Yi[nXn-1] << "];" << endl;
                }
            }
        }
    }
    // return the number of features detected
    return nXn;
}
//---end of findPoints function--------------------------------------------------------------------


//---MahalanobisTest function----------------------------------------------------------------------
int MahalanobisTest(double ptX, double ptY)
{
    double detf[]={ptX,ptY};
    tmat<double> detFeat(2,1,detf);
    tmat<double> zhat(2,1,0.0);
	tmat<double> fi(2,1,0.0);
    tmat<double> r(2,1,0.0);
    tmat<double> Si(2,2,0.0);
    double minDist = 0.090; // gamma squared, where gamma is 3 - check if this value works
    tmat<double> tempDist(1,1,0.0);
    int minInd = 0;
    
    
    for (int i=0;i<robotState.numfeatures;i++)
    {
        zhat = robotState.get_zhat(i+1);
        Si = robotState.get_res_covariance(i+1);
        r = detFeat - zhat;
        tempDist = transpose(r)*inv(Si)*r;
        //tmat<double> sinv = inv(Si);
        //cout << sinv << endl;
        fi = robotState.get_fi(i+1);
		cout << "Point     [ " << ptX << " , " << ptY << " ]" << endl;
		cout << "zhat  [ " << zhat(1,1) << " , " << zhat(2,1) << " ]" << endl;
        cout << "Mahalanobis distance to Landmark " << i+1 << " is " << fabs(tempDist(1,1)) << endl;
        if (fabs(tempDist(1,1)) <= minDist)
        {
            minDist = tempDist(1,1);
            minInd = i+1;
        }
    }
    // cout << "minDist is " << minDist << "  minInd is " <<  minInd << endl << endl;
    return minInd;
}
//---end of MahalanobisTest function---------------------------------------------------------------






// Time to make a turn! we are going to hit the front wall!!
bool TimeToMakeTurn()
{
    float distToFrontWall = 0;
    bool bRet = false;
    sick.lockDevice();
    readings = sick.getRawReadingsAsVector();
    sick.unlockDevice();
    
    for(int i=0;i<=20;i=i+2)
    {
        distToFrontWall += fabs(((*readings)[80+i].getRange())*sin((80+i)*PI/180));
    }
    distToFrontWall/=10;  // average distance of the front wall from the laser center!
    if (distToFrontWall < FRONT_WALL_THRESHOLD)
    {
        bRet = true;
    }
    return bRet;
    
}

void MakeTurn()
{
    //// find the readings which have the max value, get that angle and make a turn in
    //// that direction.
    sick.lockDevice();
    readings = sick.getRawReadingsAsVector();
    sick.unlockDevice();
    
    double max_range = 0.0;
    double sum = 0.0;
    double max_theta = 0.0;
	ArTime myTime;
    // goes around the entire range, takes chunks of 10 angles and finds the
    // avg range in tht window. We find the most promising of the theta
    // note if there are multiple interesting directions, we can actually make
    // a decision based on the current heading and min turn angle! for later work!
    for (double theta=10.0;theta<170.0; theta+=10.0)
    {
        sum = 0.0;
        for (int i=0;i<10; i++)
        {
            sum += (*readings)[theta+i].getRange();
        }
        sum /= 10.0;
        if (sum > max_range)
        {
            max_range = sum;
            max_theta = theta;
        }
    }
    printf("%Decided on a turn angle of %lf\n",(+90.0 - max_theta ));
    
    // for 170 it shud be -90 and for 10 it shud be 90
    max_theta = (max_theta > 90.0) ? (80 - max_theta) : (100 - max_theta);
    
    robot.lock();
    robot.setVel(0);
    robot.setVel2(0.0, 0.0);
    robot.unlock();
    	
	robot.lock();
	robot.setDeltaHeading(double(max_theta)/2);
	robot.unlock();

	while(!robot.isHeadingDone())
	{
		while(myTime.mSecSince() < 50 );
		float vm = robot.getVel();
		float wm = robot.getRotVel();		

		cout  << "vm = " << vm << " " << "wm =" << wm << endl;
		robotState = EKF_propagate(robotState, vm, wm, 0.05, 0.01*vm, .04*vm);
	}


    //ArUtil::sleep(1000);
    
    robot.lock();
    robot.setVel(vmax);
    robot.unlock();
    return;
}
